export default {
  apiVersion: 1,
  async create() {
    return {
      async createProvider() {
        return {
          async inspect() { return { readiness: 'ready', features: ['author-add'] } },
          async load() {},
          async invoke(request) {
            const input = request.input ?? {}
            return { sum: Number(input.a) + Number(input.b) }
          },
          async unload() {},
          async dispose() {},
        }
      },
      async dispose() {},
    }
  },
}
